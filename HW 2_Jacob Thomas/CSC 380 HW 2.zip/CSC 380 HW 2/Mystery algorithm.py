import time

def Mystery(n):
    s=0
    for i in range(1,n+1):
        s=s+(i*i)

    return print(s)

Mystery(2)


# print("N\tMystery")
# for t in range(10000, 10000000, 250000):
#     start = time.clock()
#     result = Mystery(t)
#     time1 = time.clock() - start
#
#     print(t, "\t", time1)