from random import *

def Enigma(a):
    for i in range(len(a)-2):
        for j in range(len(a)-1):
            if a[i][j]!=a[j][i]:
                return print("False")

    return print("True")

matrix=[[0 for x in range(5)] for x in range(5)]

Enigma(matrix)

# print("N\Enimga")
# for t in range(10000, 10000000, 250000):
#     start = time.clock()
#     result = Enimga(randint(1,1000000))
#     time1 = time.clock() - start
#
#     print(t, "\t", time1)