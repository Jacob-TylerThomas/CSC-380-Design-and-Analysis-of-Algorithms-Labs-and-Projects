import time
from random import *

def Q(n):
    if n==1:
        return n
    else:
        return Q(n-1)+2*n-1

print(Q(3))

# print("N\tQ(n)")
# for t in range(1,1000, 15):
#     start = time.clock()
#     result = Q(t)
#     time1 = time.clock() - start
#
#     print(t, "\t", time1)