import time
from random import *

def Riddle(a):
    if len(a)==1:
        return a[0]
    else:
        temp=Riddle(a[0:-1])
        if temp<=a[-1]:
            return temp
        else:
            return a[-1]


a=[10,8,5,3,7]

print(Riddle(a))

# print("N\tRiddle")
# for t in range(10000, 10000000, 25000):
#     start = time.clock()
#     result = Riddle(a)
#     time1 = time.clock() - start
#     a.append(randint(1,10000000))
#     print(t, "\t", time1)